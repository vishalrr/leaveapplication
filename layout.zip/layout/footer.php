<div class="footer">
  <div class="container">
    <p class="text-center">Copyright To MansaInfotech. All Rights Reserved</p>
  </div>
</div>
